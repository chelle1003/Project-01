package com.michelle.project1

import android.content.Intent
import android.icu.util.Calendar
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_depan)
        val gr1 = findViewById<RadioGroup>(R.id.rgAs)
        val asalYogya = findViewById<RadioButton>(R.id.rbYogya)
        val asalBali = findViewById<RadioButton>(R.id.rbBali)
        val asalJakakta = findViewById<RadioButton>(R.id.rbJakarta)


        val gr2 = findViewById<RadioGroup>(R.id.radio)
        val tujuanYogya = findViewById<RadioButton>(R.id.rbJogja)
        val tujuanBali = findViewById<RadioButton>(R.id.rbbale)
        val tujuanJakarta = findViewById<RadioButton>(R.id.rbJkt)

        val date = findViewById<DatePicker>(R.id.datepick)as DatePicker
        val Kalender : Calendar = Calendar.getInstance()
        date.init(Kalender.get(Calendar.YEAR),Kalender.get(Calendar.MONTH),Kalender.get(Calendar.DAY_OF_MONTH),{view,year,monthofYear,dayofMonth->})
            Toast.makeText(applicationContext,"#"+ date.dayOfMonth+"-"+date.month+"-"+date.year+"#", Toast.LENGTH_SHORT).show()

        val button1 = findViewById<Button>(R.id.button3)

        button1.setOnClickListener() {
            val i = Intent(this, belakang::class.java);
            val intSelectButton1: Int = gr1.checkedRadioButtonId
            val asal = findViewById<RadioButton>(intSelectButton1)
            val intSelectButton2: Int = gr2.checkedRadioButtonId
            val tujuan = findViewById<RadioButton>(intSelectButton2)
            i.putExtra("kotaAsal", asal.text)
            i.putExtra("kotaTujuan", tujuan.text)
            startActivity(i)
        }
    }
}